const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, x-awert-token",
  "Access-Control-Max-Age": "86400",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });
}

async function tokenMatches(supplied, expected) {
  if (!supplied || !expected) return false;
  const enc = new TextEncoder();
  const [a, b] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(supplied)),
    crypto.subtle.digest("SHA-256", enc.encode(expected)),
  ]);
  const aa = new Uint8Array(a), bb = new Uint8Array(b);
  let diff = 0;
  for (let i = 0; i < aa.length; i++) diff |= aa[i] ^ bb[i];
  return diff === 0;
}

const SYSTEM = "Ти — AWERT AI, помічник для створення якісного контенту. Відповідай конкретно, структуровано, без вигаданих фактів. Якщо факт не впевнений — познач це. Дотримуйся мови, заданої користувачем.";
function instructions(task, language) {
  const lang = ({ uk: "українською", en: "англійською", ru: "російською", pl: "польською" })[language] || "мовою користувача";
  const tasks = {
    shorts: "Створи динамічний сценарій YouTube Shorts/TikTok з сильним гачком у перші 2 секунди, логічним розвитком і закликом до дії. Не вигадуй біографічні факти.",
    seo: "Створи 5 сильних назв, короткий опис і релевантні хештеги. Не обіцяй гарантовані перегляди.",
    translate: "Переклади точно, зберігаючи сенс, стиль і формат.",
    rewrite: "Покращи текст, зроби його ясним, природним і виразним, не змінюй факти.",
    general: "Дай корисну й точну відповідь на запит користувача.",
  };
  return `${SYSTEM}\nМова відповіді: ${lang}.\nЗавдання: ${tasks[task] || tasks.general}`;
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/health") {
      return json({ ok: true, service: "AWERT AI Cloud API", providers: { openai: false, gemini: Boolean(env.GEMINI_API_KEY), ollama: false }, model: env.GEMINI_MODEL || "gemini-flash-latest" });
    }
    if (request.method !== "POST" || url.pathname !== "/api/generate") return json({ error: "Маршрут не знайдено" }, 404);
    if (!env.AWERT_APP_TOKEN || !env.GEMINI_API_KEY) return json({ error: "Хмарний сервер ще не налаштований: додай секрети AWERT_APP_TOKEN та GEMINI_API_KEY у Cloudflare." }, 503);
    if (!(await tokenMatches(request.headers.get("x-awert-token") || "", env.AWERT_APP_TOKEN))) return json({ error: "Невірний токен доступу" }, 401);
    const length = Number(request.headers.get("content-length") || 0);
    if (length > 16000) return json({ error: "Запит завеликий" }, 413);
    let body;
    try { body = await request.json(); } catch { return json({ error: "Некоректний JSON" }, 400); }
    const { provider = "gemini", task = "general", language = "uk", prompt = "" } = body || {};
    if (provider !== "gemini") return json({ error: "Цей сервер налаштований для Gemini Cloud." }, 400);
    if (typeof prompt !== "string" || !prompt.trim()) return json({ error: "Порожній запит" }, 400);
    if (prompt.length > 12000) return json({ error: "Запит задовгий (максимум 12000 символів)" }, 413);
    const model = env.GEMINI_MODEL || "gemini-flash-latest";
    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: instructions(task, language) }] },
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: 4096, temperature: 0.7 },
        }),
        signal: AbortSignal.timeout(60000),
      });
      const data = await response.json();
      if (!response.ok) {
        console.error("Gemini API error", response.status, data?.error?.message || "unknown");
        return json({ error: `Gemini API повернув помилку ${response.status}. Перевір доступність моделі та ліміти API.` }, 502);
      }
      const text = (data.candidates?.[0]?.content?.parts || []).map(part => part.text || "").join("\n").trim();
      return json({ provider: "gemini", text: text || "Gemini не повернув текст." });
    } catch (error) {
      console.error("AWERT Worker error", error?.name || "Error");
      return json({ error: error?.name === "TimeoutError" ? "Gemini не відповів вчасно." : "Не вдалося зв’язатися з Gemini API." }, 502);
    }
  },
};
