# AWERT AI Cloud API — Cloudflare Workers + Gemini

Серверний адаптер для AWERT AI 3.1. Gemini API key зберігається лише у Cloudflare Secret, не в Android APK.

## Що потрібно
- Акаунт Cloudflare з доступом до Workers.
- Новий Gemini API key з https://aistudio.google.com/apikey
- Node.js 20+ на Windows / macOS / Linux для одноразового розгортання.

## Важливо про ключ, який надсилали в чат
Не використовуйте його повторно. Він був опублікований у чаті, тому відкличте його в Google AI Studio та створіть новий. Новий ключ не надсилайте в чат і не додавайте до файлів проєкту.

## Розгортання (Windows PowerShell)
1. Відкрийте PowerShell у папці `cloudflare-worker`.
2. Виконайте `npm install`.
3. Виконайте `npx wrangler login` та підтвердьте авторизацію у браузері.
4. Додайте новий Gemini ключ командою `npx wrangler secret put GEMINI_API_KEY`. Вставте його у запит Wrangler у терміналі.
5. Створіть токен застосунку в PowerShell:
   ```powershell
   $bytes = New-Object byte[] 32
   [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
   $token = [Convert]::ToHexString($bytes).ToLower()
   Set-Content -NoNewline -Encoding ascii ..\AWERT_APP_TOKEN.txt $token
   ```
6. Виконайте `npx wrangler secret put AWERT_APP_TOKEN`. Відкрийте `AWERT_APP_TOKEN.txt`, скопіюйте значення та вставте його у запит Wrangler. Файл з токеном не завантажуйте в GitHub і не надсилайте в чат.
7. Виконайте `npm run deploy`. Wrangler покаже адресу на кшталт `https://awert-ai-cloud-api.<твій-subdomain>.workers.dev`.
8. Перевірте `https://<твій-worker>.workers.dev/health`. Очікується `ok: true` і `providers.gemini: true`.

## Підключення Android
1. Встановіть APK.
2. Відкрийте Налаштування.
3. Вставте адресу Worker (без `/health`).
4. Вставте значення з `AWERT_APP_TOKEN.txt` у поле токена.
5. Натисніть «Зберегти й перевірити».
6. Якщо сервер підключено, запустіть тестову генерацію.

## Збірка APK через GitHub Actions
1. Створіть приватний GitHub-репозиторій і завантажте в нього вміст папки `awert-ai-universal`.
2. Відкрийте Actions → Build APK → Run workflow.
3. Після успішного запуску завантажте artifact `awert-ai-debug-apk`.
4. Усередині artifact буде APK для встановлення на Android.

## Безпека й обмеження
- НІКОЛИ не вбудовуйте `GEMINI_API_KEY` у APK, JavaScript, Git або ZIP.
- `AWERT_APP_TOKEN` — приватний токен доступу до вашого Worker. Для особистого використання зберігайте його лише у себе. Для публічного розповсюдження потрібна окрема авторизація користувачів, квоти та rate limiting.
- Безкоштовні тарифи Gemini та Cloudflare мають обмеження; вони не є безлімітними й можуть змінюватися.
- Не надсилайте конфіденційні дані у запити до безкоштовного тарифу Gemini.
- Сервер не був розгорнутий автоматично: це потребує входу у ваш Cloudflare та додавання вашого нового секрету.

## Модель
За замовчуванням використовується `gemini-flash-latest` — той самий model alias, що й у наданому вами прикладі API.
