package ua.awert.ai

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#F2F4F8"))
        root.setOnApplyWindowInsetsListener { v, insets ->
            val p = insetPadding(insets)
            v.setPadding(p[0], p[1], p[2], p[3])
            insets
        }
        webView = WebView(this)
        webView.setBackgroundColor(Color.TRANSPARENT)
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false          // file:///android_asset still works
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "file" && u.path?.startsWith("/android_asset/") == true) return false
                openExternal(u)
                return true
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.requestApplyInsets()
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    private fun insetPadding(i: WindowInsets): IntArray =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = i.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime())
            intArrayOf(b.left, b.top, b.right, b.bottom)
        } else intArrayOf(i.systemWindowInsetLeft, i.systemWindowInsetTop, i.systemWindowInsetRight, i.systemWindowInsetBottom)

    private fun openExternal(u: Uri) {
        if (u.scheme == "https" || u.scheme == "http") {
            try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) { toast("Не вдалося відкрити посилання") }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun js(code: String) {
        if (::webView.isInitialized) runOnUiThread { webView.evaluateJavascript(code, null) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = js("window.awertTts&&window.awertTts('start')")
            override fun onDone(id: String?) { if (id == "awert-end") js("window.awertTts&&window.awertTts('stop')") }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) = js("window.awertTts&&window.awertTts('stop')")
        })
    }

    private fun splitText(text: String, max: Int = 3500): List<String> {
        val out = mutableListOf<String>()
        var rest = text.trim()
        while (rest.length > max) {
            var cut = rest.lastIndexOfAny(charArrayOf('.', '!', '?', '\n'), max)
            if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
            if (cut < max / 2) cut = max
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) out.add(rest)
        return out
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun speak(text: String, language: String, rate: Double) {
            runOnUiThread {
                val engine = tts
                if (!ttsReady || engine == null) { toast("Системне озвучення ще запускається"); return@runOnUiThread }
                val r = engine.setLanguage(Locale.forLanguageTag(language))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    toast("Для цієї мови встанови голосові дані Android"); return@runOnUiThread
                }
                engine.setSpeechRate(rate.toFloat().coerceIn(0.5f, 2.0f))
                val parts = splitText(text)
                parts.forEachIndexed { i, p ->
                    engine.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null,
                        if (i == parts.lastIndex) "awert-end" else "awert-$i")
                }
            }
        }

        @JavascriptInterface
        fun stopSpeaking() { runOnUiThread { tts?.stop(); js("window.awertTts&&window.awertTts('stop')") } }

        @JavascriptInterface
        fun openUrl(url: String) { runOnUiThread { openExternal(Uri.parse(url)) } }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("awert", text))
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Поділитися"))
            }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun setChrome(bg: String, lightBackground: Boolean) {
            runOnUiThread {
                val c = try { Color.parseColor(bg) } catch (_: Exception) { return@runOnUiThread }
                root.setBackgroundColor(c)
                window.statusBarColor = c
                window.navigationBarColor = c
                if (Build.VERSION.SDK_INT >= 30) {
                    val m = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                    window.insetsController?.setSystemBarsAppearance(if (lightBackground) m else 0, m)
                } else {
                    val m = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                    val f = window.decorView.systemUiVisibility
                    window.decorView.systemUiVisibility = if (lightBackground) f or m else f and m.inv()
                }
            }
        }

        @JavascriptInterface
        fun saveVideo(base64: String, filename: String, mime: String) {
            Thread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, filename)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, "Download")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Не вдалося створити файл")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: throw IllegalStateException("Не вдалося записати файл")
                    runOnUiThread { toast("Відео збережено в папку Завантаження") }
                } catch (e: Exception) {
                    runOnUiThread { toast("Помилка збереження відео: ${e.message}") }
                }
            }.start()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        webView.evaluateJavascript("window.awertBack?window.awertBack():false") { r ->
            if (r != "true") finish()
        }
    }

    override fun onPause() { tts?.stop(); super.onPause() }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
