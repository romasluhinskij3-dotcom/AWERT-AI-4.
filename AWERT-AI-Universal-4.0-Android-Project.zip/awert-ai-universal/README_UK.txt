AWERT AI — ОДНА ПРОГРАМА З ТРЬОМА AI-ПРОВАЙДЕРАМИ

Усі три AI-сервіси знаходяться в одному Android-застосунку:
1. OpenAI
2. Google Gemini
3. Ollama / open-source

У вкладці AWERT AI перемикай провайдера у списку. Інтерфейс, історія, сценарії,
SEO, переклад та озвучення залишаються в одному застосунку.

У ZIP є Android Studio проєкт і окремий сервер AWERT AI API.
Це вихідний проєкт, не готовий APK. Щоб AI працював, потрібно розгорнути сервер
і додати власні API-ключі у server/.env. Ключі не зберігай в APK.
Інструкції: server/README_UK.md

APK без Android Studio: завантаж папку на GitHub → Actions → "Build APK" → Run workflow →
забери awert-ai-debug-apk з Artifacts. Сервер не запуститься без AWERT_APP_TOKEN (мін. 16 символів).


ХМАРНА ВЕРСІЯ GEMINI + CLOUDFLARE
Дивись SETUP_CLOUD_UK.txt та cloudflare-worker/README_UK.md. Gemini key зберігай лише у Cloudflare Secrets, не в APK.
